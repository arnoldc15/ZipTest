﻿namespace ZipTest.Persistence;

public static class Db
{
    public static readonly List<PointsRange> Age
        = new()
        {
            new PointsRange { Min = 18, Max = 25, Points = 3 },
            new PointsRange { Min = 26, Max = 35, Points = 4 },
            new PointsRange { Min = 35, Max = 50, Points = 5 },
            new PointsRange { Min = 51, Max = 100, Points = 6 }
        };

    public static readonly List<PointsRange> AvailableCredit
        = new()
        {
            new PointsRange { Min = 0, Points = 0 },
            new PointsRange { Min = 1, Points = 100 },
            new PointsRange { Min = 2, Points = 200 },
            new PointsRange { Min = 3, Points = 300 },
            new PointsRange { Min = 4, Points = 400 },
            new PointsRange { Min = 5, Points = 500 },
            new PointsRange { Min = 6, Points = 600 }
        };

    public static readonly List<PointsRange> BureauScore
        = new()
        {
            new PointsRange { Min = 451, Max = 700, Points = 1 },
            new PointsRange { Min = 701, Max = 850, Points = 2 },
            new PointsRange { Min = 851, Max = 1000, Points = 3 }
        };

    public static readonly List<PointsRange> CompletedPayments
        = new()
        {
            new PointsRange { Min = 0, Points = 0 },
            new PointsRange { Min = 1, Points = 2 },
            new PointsRange { Min = 2, Points = 3 },
            new PointsRange { Min = 3, Points = 4 }
        };

    public static readonly List<PointsRange> MissedPayments
        = new()
        {
            new PointsRange { Min = 0, Points = 0 },
            new PointsRange { Min = 1, Points = -1 },
            new PointsRange { Min = 2, Points = -2 },
            new PointsRange { Min = 3, Points = -6 }
        };
}

public class PointsRange
{
    public int Min { get; set; }
    public int? Max { get; set; }
    public int Points { get; set; }
}