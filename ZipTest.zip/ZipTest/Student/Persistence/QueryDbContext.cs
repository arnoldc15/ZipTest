﻿using Microsoft.EntityFrameworkCore;
using Student.Application.Interfaces;
using Student.Domain.Entities;
using Student.Persistence.Configurations;

namespace Student.Persistence;

public class QueryDbContext : DbContext, IQueryDbContext
{
    public QueryDbContext(DbContextOptions options) : base(options)
    {
        Database.EnsureCreated();
    }

    public DbSet<Domain.Entities.Student> Student { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(StudentConfiguration).Assembly);

        modelBuilder.Entity<Domain.Entities.Student>().HasData(
            new Domain.Entities.Student { StudentId = 1, FirstName = "John", LastName = "Doe" },
            new Domain.Entities.Student { StudentId = 2, FirstName = "Jane", LastName = "Doe" });

        modelBuilder.Entity<Enrolment>().HasData(
            new Enrolment
            {
                EnrolmentId = 1,
                StudentId = 1,
                CourseName = "Course1"
            },
            new Enrolment
            {
                EnrolmentId = 2,
                StudentId = 2,
                CourseName = "Course1"
            });
    }
}