﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Student.Persistence.Configurations.CdcTables;

public class EnrolmentConfiguration : IEntityTypeConfiguration<Domain.Entities.Enrolment>
{
    public void Configure(EntityTypeBuilder<Domain.Entities.Enrolment> builder)
    {
        builder.ToTable("enrolmentSnapshot");
        builder.HasKey("EnrolmentId");
    }
}