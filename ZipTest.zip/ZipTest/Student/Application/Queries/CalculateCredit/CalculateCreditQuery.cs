﻿using MediatR;
using ZipTest.Persistence;

namespace ZipTest.Application.Queries.CalculateCredit;

public class CalculateCreditQuery : IRequest<decimal>
{
    public int BureauScore { get; set; }
    public int MissedPaymentCount { get; set; }
    public int CompletedPaymentCount { get; set; }
    public int AgeInYears { get; set; }

    public class GetStudentQueryHandler : IRequestHandler<CalculateCreditQuery, decimal>
    {
        public async Task<decimal> Handle(CalculateCreditQuery request, CancellationToken cancellationToken)
        {
            var accumulatedPoints = GetBureauScorePoints(request.BureauScore) +
                                    GetMissedPaymentPoints(request.MissedPaymentCount) +
                                    GetCompletedPaymentPoints(request.CompletedPaymentCount);

            var maxPoints = GetAgePoints(request.AgeInYears, accumulatedPoints);

            return GetCredit(maxPoints);
        }

        private static int GetBureauScorePoints(int bureauScore)
        {
            if (Db.BureauScore.Min(b => b.Min) > bureauScore)
                throw new InvalidDataException("Not Allowed in Zip");

            return Db.BureauScore.FirstOrDefault(b => b.Min <= bureauScore && b.Max >= bureauScore)!.Points;
        }

        private static int GetMissedPaymentPoints(int missedPayments)
        {
            return Db.MissedPayments.Max(b => b.Min) < missedPayments
                ? Db.MissedPayments.Max(m => m.Points)
                : Db.MissedPayments.FirstOrDefault(b => b.Min == missedPayments)!.Points;
        }

        private static int GetCompletedPaymentPoints(int completedPayments)
        {
            return Db.CompletedPayments.Max(b => b.Min) < completedPayments
                ? Db.CompletedPayments.Max(m => m.Points)
                : Db.CompletedPayments.FirstOrDefault(b => b.Min == completedPayments)!.Points;
        }

        private static int GetAgePoints(int age, int accumulatedPoints)
        {
            if (Db.Age.Min(b => b.Min) > age)
                throw new InvalidDataException("Not Allowed in Zip");

            var maxPoints = Db.Age.FirstOrDefault(b => b.Min <= age && b.Max >= age)!.Points;

            return accumulatedPoints > maxPoints ? maxPoints : accumulatedPoints;
        }

        private static int GetCredit(int points)
        {
            return points < 1
                ? 0
                : Db.AvailableCredit.Max(b => b.Min) < points
                    ? Db.AvailableCredit.Max(m => m.Points)
                    : Db.AvailableCredit.FirstOrDefault(b => b.Min == points)!.Points;
        }
    }
}