﻿using System.IO;
using System.Threading;
using AutoFixture;
using Shouldly;
using Xunit;
using ZipTest.Application.Queries.CalculateCredit;

namespace ZipTest.Tests.Application.Queries;

public class CalculateCreditQueryTests
{
    protected readonly IFixture Fixture;

    public CalculateCreditQueryTests()
    {
        Fixture = new Fixture();
    }

    [Fact]
    public async void WhenAgeIsLessThanMin_ShouldThrowInvalidDataException()
    {
        var query = Fixture.Build<CalculateCreditQuery>()
            .With(c => c.AgeInYears, 1)
            .Create();

        var handler = new CalculateCreditQuery.GetStudentQueryHandler();

        await handler.Handle(query, CancellationToken.None).ShouldThrowAsync<InvalidDataException>();
    }

    [Fact]
    public async void WhenBureauScoreIsLessThanMin_ShouldThrowInvalidDataException()
    {
        var query = Fixture.Build<CalculateCreditQuery>()
            .With(c => c.BureauScore, 10)
            .Create();

        var handler = new CalculateCreditQuery.GetStudentQueryHandler();

        await handler.Handle(query, CancellationToken.None).ShouldThrowAsync<InvalidDataException>();
    }


    [Fact]
    public async void WhenAgeLimitIsMoreThanAccumulatePoints_ShouldReturnAccumulatedPoints()
    {
        var query = Fixture.Build<CalculateCreditQuery>()
            .With(c => c.AgeInYears, 29)
            .With(c => c.BureauScore, 750)
            .With(c => c.MissedPaymentCount, 2)
            .With(c => c.CompletedPaymentCount, 1)
            .Create();

        var handler = new CalculateCreditQuery.GetStudentQueryHandler();

        var result = await handler.Handle(query, CancellationToken.None);
        result.ShouldBe(200);
    }

    [Fact]
    public async void WhenAgeLimitIsLessAccumulatePoints_ShouldReturnMaxPointCredit()
    {
        var query = Fixture.Build<CalculateCreditQuery>()
            .With(c => c.AgeInYears, 29)
            .With(c => c.BureauScore, 750)
            .With(c => c.MissedPaymentCount, 1)
            .With(c => c.CompletedPaymentCount, 4)
            .Create();

        var handler = new CalculateCreditQuery.GetStudentQueryHandler();

        var result = await handler.Handle(query, CancellationToken.None);
        result.ShouldBe(400);
    }


    [Theory]
    [InlineData(800, 50, 1, 1, 300)]
    [InlineData(750, 40, 2, 3, 0)]
    [InlineData(900, 20, 4, 5, 300)]
    [InlineData(1000, 30, 6, 7, 400)]
    public async void WhenDataIsValid_ShouldReturnCorrectCredit(int bureauScore, int ageInYears,
        int completedPaymentCount, int missedPaymentCount, int credit)
    {
        var query = Fixture.Build<CalculateCreditQuery>()
            .With(c => c.AgeInYears, ageInYears)
            .With(c => c.BureauScore, bureauScore)
            .With(c => c.MissedPaymentCount, missedPaymentCount)
            .With(c => c.CompletedPaymentCount, completedPaymentCount)
            .Create();

        var handler = new CalculateCreditQuery.GetStudentQueryHandler();

        var result = await handler.Handle(query, CancellationToken.None);
        result.ShouldBe(credit);
    }
}