using MediatR;
using Microsoft.AspNetCore.Mvc;
using ZipTest.Application.Queries.CalculateCredit;


namespace ZipTest.WebApi.Controllers;

[ApiController]
[Route("[controller]")]
public class CalculateController : ControllerBase
{
    private readonly IMediator _mediator;

    public CalculateController(IMediator mediator)
    {
        _mediator = mediator;
    }

    [HttpGet]
    public async Task<decimal> CalculateQuery(int bureauScore, int ageInYears, int completedPaymentCount, int missedPaymentCount,
        CancellationToken cancellationToken)
    {
        var query = new CalculateCreditQuery
        {
            BureauScore = bureauScore,
            AgeInYears = ageInYears,
            CompletedPaymentCount = completedPaymentCount,
            MissedPaymentCount = missedPaymentCount
        };

        return await _mediator.Send(query, cancellationToken);
    }
}